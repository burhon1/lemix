COURSES_CHOICES = (
    (1, "Offline"),
    (2, "Online")
)

DAYS_CHOICES =(
    (1, "Du, Cho, Ju"),
    (2, "Se, Pa, Sha"),
    (3, "Du,Se,Cho,Pa,Ju"),
    (4, "Du,Se,Cho,Pa,Ju,Sha"),
    (5, "Du,Pa"),
    (6, "Se,Ju"),
)

LESSONS_CHOICES = (
    (1, "Video"),
    (2, "Maqola"),
    (3, "Test")
)

LESSONS_STATUS_CHOICES = (
    (1, "Ko'rilyapti"),
    (2, "Ko'rildi")
)

FILE_TYPES_CHOICES = (
    (1, "PDF"),
    (2, "MP3")
)