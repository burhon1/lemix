from django.shortcuts import render

# Create your views here.

def test2_view(request):
    return render(request,'education/test.html')    