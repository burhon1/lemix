COURSES_SEXES = (
    (1, "Erkak"),
    (2, "Ayol")
)

COURSES_STATUS = (
    (1,"So'rovlar"),
    (2,"Aloqaga chiqildi"),
    (3,"Sinov rejalashtirilgan"),
    (4,"To'lov qildi")
)
